{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2026-05-30 09:46",
    "md5": "017acad64aadcd17f0ffe1ce78ccdc1c",
    "count": "4148"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2026-01-07 14:10",
    "md5": "adee981922b1b825bcf67448ed2f1e74",
    "count": "7166",
    "count_ip": "773446841454",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2026-05-30 09:46",
    "md5": "6f35134c9be5cbf7f6ae5b1959f90cf9",
    "count": "113124"
  }
}

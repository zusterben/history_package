{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2024-03-17 16:36",
    "md5": "fe2d7e14b4c17dbf4eaa47ca4c828128",
    "count": "5721"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2024-03-17 16:36",
    "md5": "8f666fc3ea51785c775b606a7fba27a2",
    "count": "6817",
    "count_ip": "374016518582",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2024-03-17 16:36",
    "md5": "68663dfdbd2e616037c6cac9affa10ec",
    "count": "72395"
  }
}

{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2024-10-29 09:08",
    "md5": "ee7214e34a606835858933e30c4f5757",
    "count": "5758"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2024-10-29 09:08",
    "md5": "73c8e0ee208a4bc719a70ed0e9ae67b2",
    "count": "7392",
    "count_ip": "481391294410",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2024-10-29 09:08",
    "md5": "fb2127f30d32762e122dc0d3c6f0b226",
    "count": "89125"
  }
}
